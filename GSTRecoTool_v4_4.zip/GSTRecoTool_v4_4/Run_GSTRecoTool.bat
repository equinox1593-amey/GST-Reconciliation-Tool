@echo off
rem Double-click to start the GST Reconciliation Tool (no installation needed).
cd /d "%~dp0"
start "" "%~dp0python\pythonw.exe" "%~dp0GSTRecoTool.py"
